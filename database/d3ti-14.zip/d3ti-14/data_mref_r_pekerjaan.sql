/*
SQLyog Community v13.1.1 (64 bit)
MySQL - 5.6.21 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

insert into `mref_r_pekerjaan` (`pekerjaan_id`, `nama`, `desc`, `deleted`, `deleted_at`, `deleted_by`, `created_by`, `created_at`, `updated_by`, `updated_at`) values('1','Pegawai Negeri Sipil',NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL);
insert into `mref_r_pekerjaan` (`pekerjaan_id`, `nama`, `desc`, `deleted`, `deleted_at`, `deleted_by`, `created_by`, `created_at`, `updated_by`, `updated_at`) values('2','Guru',NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL);
insert into `mref_r_pekerjaan` (`pekerjaan_id`, `nama`, `desc`, `deleted`, `deleted_at`, `deleted_by`, `created_by`, `created_at`, `updated_by`, `updated_at`) values('3','Pejabat Pemerintah',NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL);
insert into `mref_r_pekerjaan` (`pekerjaan_id`, `nama`, `desc`, `deleted`, `deleted_at`, `deleted_by`, `created_by`, `created_at`, `updated_by`, `updated_at`) values('4','TNI/Polri',NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL);
insert into `mref_r_pekerjaan` (`pekerjaan_id`, `nama`, `desc`, `deleted`, `deleted_at`, `deleted_by`, `created_by`, `created_at`, `updated_by`, `updated_at`) values('5','Wiraswasta',NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL);
insert into `mref_r_pekerjaan` (`pekerjaan_id`, `nama`, `desc`, `deleted`, `deleted_at`, `deleted_by`, `created_by`, `created_at`, `updated_by`, `updated_at`) values('6','Karyawan Swasta',NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL);
insert into `mref_r_pekerjaan` (`pekerjaan_id`, `nama`, `desc`, `deleted`, `deleted_at`, `deleted_by`, `created_by`, `created_at`, `updated_by`, `updated_at`) values('7','Petani',NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL);
insert into `mref_r_pekerjaan` (`pekerjaan_id`, `nama`, `desc`, `deleted`, `deleted_at`, `deleted_by`, `created_by`, `created_at`, `updated_by`, `updated_at`) values('8','Lainnya',NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL);
