/*
SQLyog Community v13.1.1 (64 bit)
MySQL - 5.6.21 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

insert into `mref_r_penghasilan` (`penghasilan_id`, `nama`, `desc`, `deleted`, `deleted_at`, `deleted_by`, `created_by`, `created_at`, `updated_by`, `updated_at`) values('7','< 1.000.000','','0',NULL,NULL,'1','2015-03-27 04:21:09','1','2015-04-30 10:05:45');
insert into `mref_r_penghasilan` (`penghasilan_id`, `nama`, `desc`, `deleted`, `deleted_at`, `deleted_by`, `created_by`, `created_at`, `updated_by`, `updated_at`) values('8','2000000 - 3500000','','0',NULL,NULL,'1','2015-04-30 10:05:59','1','2015-04-30 10:05:59');
insert into `mref_r_penghasilan` (`penghasilan_id`, `nama`, `desc`, `deleted`, `deleted_at`, `deleted_by`, `created_by`, `created_at`, `updated_by`, `updated_at`) values('9','5000000 -10000000','5 Juta sampai 10 juta','0',NULL,NULL,'1457','2015-09-09 15:34:38','1457','2015-09-09 15:35:24');
insert into `mref_r_penghasilan` (`penghasilan_id`, `nama`, `desc`, `deleted`, `deleted_at`, `deleted_by`, `created_by`, `created_at`, `updated_by`, `updated_at`) values('10','>10000000','di atas 10 Juta','0',NULL,NULL,'1457','2015-09-09 15:34:56','1457','2015-09-09 15:34:56');
